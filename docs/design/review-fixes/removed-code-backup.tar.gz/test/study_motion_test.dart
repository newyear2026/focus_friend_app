import 'package:flutter_test/flutter_test.dart';
import 'package:focus_friend_app/study_motion.dart';

void main() {
  test(
    'joint lengths and pencil grip remain attached for the entire action',
    () {
      for (var frame = 0; frame < 24 * 120; frame++) {
        final pose = StudyMotion.sample(frame / 120);
        expect(
          (pose.left.elbow - pose.left.shoulder).distance,
          closeTo(44, .0001),
        );
        expect(
          (pose.left.wrist - pose.left.elbow).distance,
          closeTo(70, .0001),
        );
        expect(
          (pose.right.elbow - pose.right.shoulder).distance,
          closeTo(51, .0001),
        );
        expect(
          (pose.right.wrist - pose.right.elbow).distance,
          closeTo(69, .0001),
        );
        expect(
          (pose.penTip - StudyMotion.penVector * 29 - pose.left.wrist).distance,
          lessThan(.0001),
          reason: 'Grip detached at ${pose.time}',
        );
      }
    },
  );

  test(
    'pen follows the revealed ink, lifts between words and turns after writing',
    () {
      for (var frame = 0; frame < 24 * 120; frame++) {
        final pose = StudyMotion.sample(frame / 120);
        if (pose.isWriting) {
          final word = StudyMotion.strokes.lastWhere(
            (word) => word.begin <= pose.time,
          );
          expect(pose.penTip, word.point(word.progress(pose.inkTime)));
          expect(pose.penLift, 0);
        }
      }
      expect(StudyMotion.sample(1.62).penLift, greaterThan(0));
      expect(StudyMotion.sample(15.5).action, StudyAction.reading);
      expect(StudyMotion.sample(17).action, StudyAction.reaching);
      expect(StudyMotion.sample(20).action, StudyAction.turning);
      expect(StudyMotion.sample(20).inkTime, greaterThan(14));
      expect(StudyMotion.sample(21.3).inkTime, 0);
      expect(StudyMotion.sample(22).action, StudyAction.returning);
    },
  );

  test('hands do not jump across keyframes or the 24-second loop', () {
    for (var frame = 0; frame <= 24 * 120; frame++) {
      final a = StudyMotion.sample(frame / 120);
      final b = StudyMotion.sample((frame + 1) / 120);
      for (final points in [
        (a.penTip, b.penTip),
        (a.left.elbow, b.left.elbow),
        (a.right.wrist, b.right.wrist),
      ]) {
        expect(
          (points.$1 - points.$2).distance,
          lessThan(6),
          reason: 'Discontinuity at ${a.time}',
        );
      }
    }
    final before = StudyMotion.sample(23.999);
    final after = StudyMotion.sample(24.001);
    expect((before.penTip - after.penTip).distance, lessThan(.01));
    expect((before.right.wrist - after.right.wrist).distance, lessThan(.01));
    expect((before.headAngle - after.headAngle).abs(), lessThan(.001));
  });

  test('blink closes then opens; idle holds the rig without ink', () {
    expect(StudyMotion.sample(3.8).blink, 1);
    expect(StudyMotion.sample(4.1).blink, 0);
    final idle = StudyMotion.sample(-1);
    expect(idle.inkTime, 0);
    expect(idle.blink, 0);
    expect(idle.breath, 0);
    expect(idle.penTip, const Offset(153, 418));
  });
}
