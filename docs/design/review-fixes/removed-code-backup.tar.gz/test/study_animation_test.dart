import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:focus_friend_app/study_scene.dart';

void main() {
  testWidgets('the face, ears and tail stay still through every authored cel', (
    tester,
  ) async {
    await tester.runAsync(() async {
      final data = await rootBundle.load(StudyAnimation.asset);
      final codec = await ui.instantiateImageCodec(data.buffer.asUint8List());
      final atlas = (await codec.getNextFrame()).image;
      codec.dispose();
      Future<ByteData> render(double seconds) async {
        final recorder = ui.PictureRecorder();
        StudyCompanionPainter(
          atlas,
          seconds,
        ).paint(Canvas(recorder), const Size(362, 362));
        final picture = recorder.endRecording();
        final image = await picture.toImage(362, 362);
        picture.dispose();
        final bytes = (await image.toByteData())!;
        image.dispose();
        return bytes;
      }

      final base = await render(-1);
      for (final action in StudyFrameAction.values) {
        for (var index = 0; index < 12; index++) {
          final tick = StudyAnimation.timeline.indexOf((
            action: action,
            index: index,
          ));
          final bytes = await render(
            (tick + .5) / StudyAnimation.framesPerSecond,
          );
          var changed = 0;
          for (var y = 0; y < 265; y++) {
            final right = y < 188 ? 362 : 80;
            for (var x = 0; x < right; x++) {
              final offset = (y * 362 + x) * 4;
              if (bytes.getUint32(offset) != base.getUint32(offset)) changed++;
            }
          }
          expect(
            changed,
            0,
            reason: '$action cel $index moved the stationary face/tail',
          );
        }
      }
      atlas.dispose();
    });
  });
  test('the approved writing, thinking and page cels play in order and loop', () {
    expect(StudyAnimation.timeline, hasLength(StudyAnimation.cycleTicks));
    for (final action in StudyFrameAction.values) {
      final indices = StudyAnimation.timeline
          .where((frame) => frame.action == action)
          .map((frame) => frame.index)
          .toSet();
      expect(indices, containsAll(List.generate(12, (i) => i)));
    }
    StudyFrame at(int milliseconds) =>
        StudyAnimation.frameAt(Duration(milliseconds: milliseconds));
    expect(at(7499).action, StudyFrameAction.writing);
    expect(at(7500), (action: StudyFrameAction.thinking, index: 0));
    expect(at(8500).index, 5);
    expect(at(9499).index, 5);
    expect(at(9500).index, 6);
    expect(at(11500), StudyAnimation.idle);
    expect(at(19000), (action: StudyFrameAction.turning, index: 0));
    expect(at(21999), (action: StudyFrameAction.turning, index: 11));
    expect(at(22000), StudyAnimation.idle);
    expect(
      StudyAnimation.frameAt(const Duration(microseconds: -1)),
      StudyAnimation.idle,
    );
    // The same cels recur after many cycles; no accumulated floating-point phase.
    for (var cycle = 0; cycle < 40; cycle++) {
      final tick = cycle * StudyAnimation.cycleTicks + 228;
      final microseconds = (tick * 1000000 + 11) ~/ 12;
      expect(StudyAnimation.frameAt(Duration(microseconds: microseconds)), (
        action: StudyFrameAction.turning,
        index: 0,
      ));
    }
  });

  test(
    'held cels do not repaint, and switching actions selects another atlas cell',
    () {
      final a = StudyCompanionPainter(null, 9.0);
      final b = StudyCompanionPainter(null, 9.4);
      expect(a.frame, b.frame);
      expect(b.shouldRepaint(a), isFalse);
      final page = StudyCompanionPainter(null, 20.0);
      expect(page.shouldRepaint(b), isTrue);
      expect(StudyAnimation.atlasIndex(page.frame), inInclusiveRange(24, 35));
    },
  );

  testWidgets(
    'pause, hidden app, and hidden ticker freeze then resume without skipping',
    (tester) async {
      var studying = true;
      var animate = true;
      var paused = false;
      var tickerEnabled = true;
      Widget harness() => MaterialApp(
        home: TickerMode(
          enabled: tickerEnabled,
          child: SizedBox(
            width: 200,
            height: 200,
            child: StudyCompanion(
              studying: studying,
              animate: animate,
              paused: paused,
            ),
          ),
        ),
      );
      StudyCompanionPainter painter() =>
          tester
                  .widget<CustomPaint>(
                    find.descendant(
                      of: find.byType(StudyCompanion),
                      matching: find.byType(CustomPaint),
                    ),
                  )
                  .painter!
              as StudyCompanionPainter;
      await tester.pumpWidget(harness());
      await tester.pump(const Duration(milliseconds: 8550));
      expect(painter().frame.action, StudyFrameAction.thinking);
      final frame = painter().frame;
      final seconds = painter().seconds;
      paused = true;
      await tester.pumpWidget(harness());
      await tester.pump(const Duration(seconds: 20));
      expect(painter().frame, frame);
      expect(painter().seconds, seconds);
      paused = false;
      animate = false; // Parent's app-lifecycle foreground gate.
      await tester.pumpWidget(harness());
      await tester.pump(const Duration(seconds: 20));
      expect(painter().seconds, seconds);
      animate = true;
      tickerEnabled = false;
      await tester.pumpWidget(harness());
      await tester.pump(const Duration(seconds: 20));
      expect(painter().seconds, seconds);
      tickerEnabled = true;
      await tester.pumpWidget(harness());
      await tester.pump(const Duration(milliseconds: 200));
      expect(painter().seconds, closeTo(seconds + .2, .02));
      studying = false;
      await tester.pumpWidget(harness());
      expect(painter().frame, StudyAnimation.idle);
      expect(painter().seconds, -1);
      studying = true;
      await tester.pumpWidget(harness());
      expect(painter().frame, StudyAnimation.idle);
      await tester.pump(const Duration(milliseconds: 200));
      expect(painter().seconds, closeTo(.2, .02));
      await tester.pumpWidget(const SizedBox.shrink());
    },
  );
}
