import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'room_ambience.dart';
import 'study_animation.dart';
import 'study_sprite.dart';
import 'reference_companion.dart';
import 'rest_companion.dart';
export 'study_animation.dart';
export 'study_sprite.dart' show StudyCompanionPainter;
export 'reference_companion.dart' show ReferenceCompanion;

class DeskIllustration extends StatelessWidget {
  const DeskIllustration({
    super.key,
    required this.unlocked,
    required this.ambience,
    this.studying = false,
    this.animate = false,
    this.paused = false,
    this.resting = false,
    this.immersive = false,
  });
  final Set<String> unlocked;
  final RoomAmbience ambience;
  final bool studying;
  final bool animate;
  final bool paused;
  final bool resting;
  final bool immersive;

  static const companionBounds = Rect.fromLTWH(370, 395, 410, 410);
  // The sprite's feet (155, 349 in a 362px cel) meet the cushion seat.
  static const restCompanionBounds = Rect.fromLTWH(815, 628, 370, 370);

  Color get _foregroundTint => switch (ambience) {
    RoomAmbience.night => const Color(0xFFBCC3E4),
    RoomAmbience.evening => const Color(0xFFFFDDCA),
    _ => Colors.white,
  };

  // Keep the authored cels intact. A gentle room light crosses the whole
  // silhouette, so every writing, page-turn and tea frame shares one light.
  Widget _roomLitCompanion(Widget child) => ShaderMask(
    blendMode: BlendMode.modulate,
    shaderCallback: (bounds) => LinearGradient(
      begin: Alignment.centerLeft,
      end: Alignment.centerRight,
      colors: switch (ambience) {
        RoomAmbience.evening => const [
          Color(0xFFD9BCC0),
          Color(0xFFF5D3BF),
          Color(0xFFFFE7BC),
        ],
        RoomAmbience.night => const [
          Color(0xFFC4B6C8),
          Color(0xFFD8C6C5),
          Color(0xFFF4D9B4),
        ],
        _ => const [Color(0xFFE8DADB), Color(0xFFFFF1DE), Color(0xFFFFF1D2)],
      },
      stops: const [0, .53, 1],
    ).createShader(bounds),
    child: child,
  );

  @override
  Widget build(BuildContext context) => Semantics(
    image: true,
    label:
        '${ambience.label}의 책상. ${resting
            ? (paused ? '찻잔을 들고 잠시 쉬는' : '차를 마시는')
            : paused
            ? '잠시 쉬는'
            : studying
            ? immersive
                  ? '노트에 필기하는'
                  : '노트에 필기하고 생각하며 페이지를 넘기는'
            : '책상에서 기다리는'} 랫서팬더. '
        '얻은 소품 ${unlocked.contains('plant') ? '화분 ' : ''}'
        '${unlocked.contains('mug') ? '머그컵 ' : ''}'
        '${unlocked.contains('lamp') ? '조명' : ''}',
    child: ExcludeSemantics(
      child: RepaintBoundary(
        key: const ValueKey('study-scene'),
        child: immersive
            ? _immersiveScene(context)
            : FittedBox(
                fit: BoxFit.contain,
                child: SizedBox(
                  width: 1182,
                  height: 1330,
                  child: Stack(
                    children: [
                      Positioned.fill(
                        child: AnimatedSwitcher(
                          duration: MediaQuery.disableAnimationsOf(context)
                              ? Duration.zero
                              : const Duration(seconds: 2),
                          child: Image.asset(
                            ambience.asset,
                            key: ValueKey(ambience),
                            width: 1182,
                            height: 1330,
                          ),
                        ),
                      ),
                      if (!resting)
                        Positioned.fromRect(
                          rect: companionBounds,
                          child: _roomLitCompanion(
                            ColorFiltered(
                              colorFilter: ColorFilter.mode(
                                _foregroundTint,
                                BlendMode.modulate,
                              ),
                              child: StudyCompanion(
                                studying: studying,
                                animate: animate,
                                paused: paused,
                              ),
                            ),
                          ),
                        ),
                      if (unlocked.contains('lamp'))
                        Positioned(
                          left: 742,
                          top: 622,
                          width: 152,
                          height: 216,
                          child: Image.asset(
                            'assets/images/storybook/reward-lamp.png',
                            color: _foregroundTint,
                            colorBlendMode: BlendMode.modulate,
                          ),
                        ),
                      if (unlocked.contains('plant'))
                        Positioned(
                          left: 692,
                          top: 644,
                          width: 114,
                          height: 164,
                          child: Image.asset(
                            'assets/images/storybook/reward-plant.png',
                            color: _foregroundTint,
                            colorBlendMode: BlendMode.modulate,
                          ),
                        ),
                      if (unlocked.contains('mug'))
                        Positioned(
                          left: 637,
                          top: 789,
                          width: 95,
                          height: 99,
                          child: Image.asset(
                            'assets/images/storybook/reward-mug.png',
                            color: _foregroundTint,
                            colorBlendMode: BlendMode.modulate,
                          ),
                        ),
                      if (resting) ...[
                        Positioned(
                          left: 492,
                          top: 649,
                          width: 240,
                          height: 220,
                          child: Image.asset(
                            'assets/images/rest/closed-book.png',
                            color: _foregroundTint,
                            colorBlendMode: BlendMode.modulate,
                          ),
                        ),
                        Positioned.fromRect(
                          rect: restCompanionBounds,
                          child: _roomLitCompanion(
                            ColorFiltered(
                              colorFilter: ColorFilter.mode(
                                _foregroundTint,
                                BlendMode.modulate,
                              ),
                              child: RestCompanion(
                                animate: animate,
                                paused: paused,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
              ),
      ),
    ),
  );

  Widget _immersiveScene(BuildContext context) => ClipRect(
    child: FittedBox(
      fit: BoxFit.cover,
      child: SizedBox(
        width: 853,
        height: 1844,
        child: Stack(
          children: [
            Positioned.fill(
              child: AnimatedSwitcher(
                duration: MediaQuery.disableAnimationsOf(context)
                    ? Duration.zero
                    : const Duration(seconds: 2),
                child: Image.asset(
                  'assets/images/immersive/room-${ambience.assetName}.png',
                  key: ValueKey(ambience),
                  width: 853,
                  height: 1844,
                  fit: BoxFit.fill,
                ),
              ),
            ),
            if (!resting)
              const Positioned.fill(
                child: CustomPaint(painter: _DeskContactShadowPainter()),
              ),
            if (!resting)
              Positioned(
                left: 90,
                top: 610,
                width: 580,
                height: 580,
                child: _roomLitCompanion(
                  ColorFiltered(
                    colorFilter: ColorFilter.mode(
                      _foregroundTint,
                      BlendMode.modulate,
                    ),
                    child: ReferenceCompanion(
                      studying: studying,
                      animate: animate,
                      paused: paused,
                    ),
                  ),
                ),
              ),
            if (!resting)
              Positioned.fill(
                child: ClipPath(
                  clipper: _ForegroundBooksClipper(),
                  child: Image.asset(
                    'assets/images/immersive/room-${ambience.assetName}.png',
                    width: 853,
                    height: 1844,
                    fit: BoxFit.fill,
                  ),
                ),
              ),
            if (resting) ...[
              const Positioned.fill(
                child: CustomPaint(painter: _RestContactShadowPainter()),
              ),
              Positioned(
                left: 105,
                top: 680,
                width: 490,
                height: 377,
                child: ClipRect(
                  child: OverflowBox(
                    alignment: Alignment.topCenter,
                    minWidth: 490,
                    maxWidth: 490,
                    minHeight: 490,
                    maxHeight: 490,
                    child: _roomLitCompanion(
                      ColorFiltered(
                        colorFilter: ColorFilter.mode(
                          _foregroundTint,
                          BlendMode.modulate,
                        ),
                        child: RestCompanion(animate: animate, paused: paused),
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                left: 222,
                top: 1033,
                width: 330,
                height: 150,
                child: Image.asset('assets/images/rest/closed-book.png'),
              ),
            ],
            if (unlocked.contains('lamp'))
              Positioned(
                left: 608,
                top: 739,
                width: 266,
                height: 400,
                child: Image.asset(
                  'assets/images/immersive/reward-lamp.png',
                  fit: BoxFit.fill,
                ),
              ),
            if (unlocked.contains('plant'))
              Positioned(
                left: 648,
                top: 957,
                width: 115,
                height: 138,
                child: Image.asset(
                  'assets/images/immersive/reward-plant.png',
                  fit: BoxFit.contain,
                  color: _foregroundTint,
                  colorBlendMode: BlendMode.modulate,
                ),
              ),
            if (unlocked.contains('mug'))
              Positioned(
                left: 613,
                top: 1010,
                width: 156,
                height: 170,
                child: Image.asset(
                  'assets/images/immersive/reward-mug.png',
                  fit: BoxFit.fill,
                  color: _foregroundTint,
                  colorBlendMode: BlendMode.modulate,
                ),
              ),
            const Positioned.fill(child: ColoredBox(color: Color(0x0A11131F))),
          ],
        ),
      ),
    ),
  );
}

class _DeskContactShadowPainter extends CustomPainter {
  const _DeskContactShadowPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final sx = size.width / 853;
    final sy = size.height / 1844;
    canvas.save();
    canvas.scale(sx, sy);
    canvas.drawOval(
      const Rect.fromLTWH(276, 1090, 355, 76),
      Paint()
        ..color = const Color(0x66282031)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 18),
    );
    canvas.drawOval(
      const Rect.fromLTWH(145, 1010, 220, 84),
      Paint()
        ..color = const Color(0x33282031)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 22),
    );
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _DeskContactShadowPainter oldDelegate) => false;
}

class _RestContactShadowPainter extends CustomPainter {
  const _RestContactShadowPainter();

  @override
  void paint(Canvas canvas, Size size) {
    canvas.save();
    canvas.scale(size.width / 853, size.height / 1844);
    canvas.drawOval(
      const Rect.fromLTWH(191, 1001, 381, 73),
      Paint()
        ..color = const Color(0x54291724)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 21),
    );
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _RestContactShadowPainter oldDelegate) => false;
}

class _ForegroundBooksClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    final sx = size.width / 853;
    final sy = size.height / 1844;
    return Path()..addPolygon([
      Offset(0, 1035 * sy),
      Offset(294 * sx, 1035 * sy),
      Offset(345 * sx, 1198 * sy),
      Offset(0, 1198 * sy),
    ], true);
  }

  @override
  bool shouldReclip(covariant _ForegroundBooksClipper oldClipper) => false;
}

/// Decorative motion never changes the durable focus timer.
class StudyCompanion extends StatefulWidget {
  const StudyCompanion({
    super.key,
    required this.studying,
    required this.animate,
    this.paused = false,
  });
  final bool studying, animate, paused;
  @override
  State<StudyCompanion> createState() => _StudyCompanionState();
}

class _StudyCompanionState extends State<StudyCompanion>
    with SingleTickerProviderStateMixin {
  late final Ticker motion = createTicker(_onTick);
  ImageStream? stream;
  ImageStreamListener? listener;
  ImageInfo? imageInfo;
  bool reducedMotion = false;
  bool tickerEnabled = true;
  Duration played = Duration.zero;
  Duration runBase = Duration.zero;
  int displayedTick = 0;

  void _onTick(Duration elapsed) {
    played = runBase + elapsed;
    final tick = StudyAnimation.tickAt(played);
    if (tick != displayedTick) setState(() => displayedTick = tick);
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    reducedMotion = MediaQuery.disableAnimationsOf(context);
    tickerEnabled = TickerMode.valuesOf(context).enabled;
    if (stream == null) {
      stream = const AssetImage(
        StudyAnimation.asset,
      ).resolve(createLocalImageConfiguration(context));
      listener = ImageStreamListener((info, _) {
        if (!mounted) {
          info.dispose();
          return;
        }
        final oldInfo = imageInfo;
        setState(() => imageInfo = info);
        oldInfo?.dispose();
      });
      stream!.addListener(listener!);
    }
    _syncMotion();
  }

  @override
  void didUpdateWidget(StudyCompanion oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.studying != oldWidget.studying) {
      motion.stop();
      runBase = Duration.zero;
      played = Duration.zero;
      displayedTick = 0;
    }
    _syncMotion();
  }

  void _syncMotion() {
    if (widget.studying &&
        widget.animate &&
        !widget.paused &&
        !reducedMotion &&
        tickerEnabled) {
      if (!motion.isActive) {
        runBase = played;
        motion.start();
      }
    } else {
      motion.stop();
    }
  }

  @override
  void dispose() {
    if (listener != null) stream?.removeListener(listener!);
    imageInfo?.dispose();
    motion.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => RepaintBoundary(
    child: CustomPaint(
      painter: StudyCompanionPainter(
        imageInfo?.image,
        widget.studying
            ? played.inMicroseconds / Duration.microsecondsPerSecond
            : -1,
        resting: widget.paused,
        reducedMotion: reducedMotion,
      ),
    ),
  );
}
