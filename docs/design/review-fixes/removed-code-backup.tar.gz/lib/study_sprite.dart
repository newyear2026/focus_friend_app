import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'study_animation.dart';

/// Keeps the approved face, body, tail and book on a stationary base cel.
/// Only the local hand/pencil/page regions use the other authored cels.
class StudyCompanionPainter extends CustomPainter {
  StudyCompanionPainter(
    this.atlas,
    this.seconds, {
    this.resting = false,
    this.reducedMotion = false,
  });

  final ui.Image? atlas;
  final double seconds;
  final bool resting, reducedMotion;

  StudyFrame get frame => StudyAnimation.frameAt(
    Duration(microseconds: (seconds * Duration.microsecondsPerSecond).round()),
  );

  // Measured book-base anchors in the original 362px cells. Registration is
  // applied at draw time; the source artwork and its alpha remain untouched.
  static const _anchors = <Offset>[
    Offset(203, 325),
    Offset(202, 325),
    Offset(202, 325),
    Offset(200, 325),
    Offset(203, 322),
    Offset(202, 322),
    Offset(202.5, 322),
    Offset(199.5, 322),
    Offset(203, 321),
    Offset(202, 321),
    Offset(202, 321),
    Offset(200, 321),
    Offset(203, 333),
    Offset(202.5, 333),
    Offset(202.5, 333),
    Offset(201.5, 333),
    Offset(202.5, 331),
    Offset(202, 331),
    Offset(202, 331),
    Offset(201, 331),
    Offset(202, 322),
    Offset(201, 322),
    Offset(201, 322),
    Offset(200, 322),
    Offset(202.5, 325),
    Offset(201.5, 325),
    Offset(201, 325),
    Offset(199.5, 325),
    Offset(202.5, 322),
    Offset(202, 322),
    Offset(201, 322),
    Offset(199.5, 322),
    Offset(202.5, 321),
    Offset(202, 321),
    Offset(201, 321),
    Offset(199.5, 321),
  ];

  static Path _polygon(List<Offset> points) => Path()..addPolygon(points, true);

  static Path _motionRegion(StudyFrame pose) {
    if (pose.action == StudyFrameAction.writing) {
      return _polygon(const [
        Offset(117, 193),
        Offset(133, 193),
        Offset(165, 247),
        Offset(187, 280),
        Offset(190, 298),
        Offset(94, 294),
        Offset(90, 268),
        Offset(89, 248),
        Offset(96, 231),
        Offset(114, 219),
      ]);
    }
    if (pose.action == StudyFrameAction.thinking) {
      var arm = _polygon(const [
        Offset(230, 233),
        Offset(306, 223),
        Offset(324, 246),
        Offset(324, 275),
        Offset(230, 278),
      ]);
      final paw = switch (pose.index) {
        2 => const Rect.fromLTWH(246, 222, 41, 40),
        3 => const Rect.fromLTWH(248, 207, 45, 45),
        4 || 5 || 6 || 7 => const Rect.fromLTWH(240, 207, 48, 48),
        8 => const Rect.fromLTWH(242, 218, 42, 43),
        _ => null,
      };
      if (paw != null) {
        arm = Path.combine(PathOperation.union, arm, Path()..addOval(paw));
      }
      return Path.combine(
        PathOperation.union,
        arm,
        _polygon(const [
          Offset(209, 271),
          Offset(325, 270),
          Offset(337, 313),
          Offset(209, 313),
        ]),
      );
    }
    var arm = Path.combine(
      PathOperation.union,
      _polygon(const [
        Offset(165, 233),
        Offset(231, 235),
        Offset(274, 227),
        Offset(309, 210),
        Offset(345, 216),
        Offset(345, 289),
        Offset(165, 289),
      ]),
      _polygon(const [
        Offset(83, 267),
        Offset(326, 267),
        Offset(338, 314),
        Offset(67, 314),
      ]),
    );
    // The lifted page crosses the writing hand. Keep that hand in the same
    // local cel so the paper edge cannot slice two different hand positions.
    arm = Path.combine(
      PathOperation.union,
      arm,
      _motionRegion((action: StudyFrameAction.writing, index: pose.index)),
    );
    final paper = switch (pose.index) {
      2 => const [Offset(205, 319), Offset(325, 256), Offset(334, 314)],
      3 => const [Offset(203, 321), Offset(321, 237), Offset(335, 311)],
      4 => const [
        Offset(200, 323),
        Offset(279, 229),
        Offset(301, 250),
        Offset(278, 306),
      ],
      5 => const [
        Offset(205, 325),
        Offset(207, 230),
        Offset(214, 194),
        Offset(220, 197),
        Offset(230, 260),
        Offset(222, 319),
      ],
      6 => const [
        Offset(139, 315),
        Offset(208, 258),
        Offset(256, 251),
        Offset(239, 321),
      ],
      7 => const [
        Offset(119, 265),
        Offset(167, 282),
        Offset(224, 291),
        Offset(248, 324),
        Offset(175, 324),
        Offset(119, 303),
      ],
      _ => const <Offset>[],
    };
    return paper.isEmpty
        ? arm
        : Path.combine(PathOperation.union, arm, _polygon(paper));
  }

  @override
  void paint(Canvas canvas, Size size) {
    final image = atlas;
    if (image == null) return;
    final pose = frame;
    final index = StudyAnimation.atlasIndex(pose);
    final width = image.width / StudyAnimation.columns;
    final height = image.height / StudyAnimation.rows;
    void draw(int cell, Offset offset) => canvas.drawImageRect(
      image,
      Rect.fromLTWH(
        (cell % StudyAnimation.columns) * width,
        (cell ~/ StudyAnimation.columns) * height,
        width,
        height,
      ),
      offset & const Size(362, 362),
      Paint()..filterQuality = FilterQuality.medium,
    );
    canvas.save();
    canvas.scale(size.width / 362, size.height / 362);
    if (index == 0) {
      draw(0, Offset.zero);
    } else {
      final region = _motionRegion(pose);
      final stationary = Path.combine(
        PathOperation.difference,
        Path()..addRect(const Rect.fromLTWH(0, 0, 362, 362)),
        region,
      );
      canvas.save();
      canvas.clipPath(stationary, doAntiAlias: false);
      draw(0, Offset.zero);
      canvas.restore();
      canvas.save();
      canvas.clipPath(region, doAntiAlias: false);
      draw(index, _anchors.first - _anchors[index]);
      canvas.restore();
    }
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant StudyCompanionPainter oldDelegate) =>
      atlas != oldDelegate.atlas || frame != oldDelegate.frame;
}
