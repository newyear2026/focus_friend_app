enum StudyFrameAction { writing, thinking, turning }

typedef StudyFrame = ({StudyFrameAction action, int index});

/// Authored cel timing only. Focus time remains owned by SessionEngine.
abstract final class StudyAnimation {
  static const asset = 'assets/images/redpanda-study-animation.png';
  static const framesPerSecond = 12;
  static const framesPerAction = 12;
  static const columns = 4;
  static const rows = 9;
  static const cycleTicks = 264;
  static const idle = (action: StudyFrameAction.writing, index: 0);

  // Each writing pass takes two seconds, followed by a half-second rest.
  // 7.5s writing → 4s thinking → 7.5s writing → 2s page turn + 1s rest.
  static List<StudyFrame> _writing() => [
    for (var repeat = 0; repeat < 3; repeat++) ...[
      for (var i = 0; i < framesPerAction; i++)
        for (var hold = 0; hold < 2; hold++)
          (action: StudyFrameAction.writing, index: i),
      for (var hold = 0; hold < 6; hold++)
        (action: StudyFrameAction.writing, index: 11),
    ],
  ];

  static final List<StudyFrame> timeline = List.unmodifiable([
    ..._writing(),
    for (var i = 0; i < framesPerAction; i++)
      for (var hold = 0; hold < (i == 5 || i == 6 ? 14 : 2); hold++)
        (action: StudyFrameAction.thinking, index: i),
    ..._writing(),
    for (var i = 0; i < framesPerAction; i++)
      for (var hold = 0; hold < 2; hold++)
        (action: StudyFrameAction.turning, index: i),
    for (var hold = 0; hold < 12; hold++)
      (action: StudyFrameAction.turning, index: 11),
  ]);

  static int tickAt(Duration elapsed) =>
      elapsed.inMicroseconds *
      framesPerSecond ~/
      Duration.microsecondsPerSecond;

  static StudyFrame frameAt(Duration elapsed) =>
      elapsed.isNegative ? idle : timeline[tickAt(elapsed) % timeline.length];

  static int atlasIndex(StudyFrame frame) =>
      frame.action.index * framesPerAction + frame.index;
}
