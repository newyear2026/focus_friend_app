/// Authored whole-character cels. This clock never changes the focus timer.
abstract final class ReferenceWritingAnimation {
  static const asset =
      'assets/images/immersive/redpanda-connected-writing-24.png';
  static const columns = 4;
  static const rows = 6;
  static const drawingCount = 24;
  static const framesPerSecond = 12;
  static const cycleTicks = 36;

  // 24 drawings, plus half a second of extra hold at each end: a 3s loop.
  static final List<int> timeline = List.unmodifiable([
    for (var hold = 0; hold < 6; hold++) 0,
    for (var frame = 0; frame < drawingCount; frame++) frame,
    for (var hold = 0; hold < 6; hold++) drawingCount - 1,
  ]);

  static int tickAt(Duration elapsed) =>
      elapsed.inMicroseconds *
      framesPerSecond ~/
      Duration.microsecondsPerSecond;

  static int frameAt(Duration elapsed) =>
      elapsed.isNegative ? 0 : timeline[tickAt(elapsed) % cycleTicks];
}
