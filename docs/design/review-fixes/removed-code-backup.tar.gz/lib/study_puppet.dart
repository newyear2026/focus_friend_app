import 'dart:math' as math;
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'study_motion.dart';

/// Rigid cutout parts, two-bone arms, an attached pencil and a turning page.
/// No pose dissolves or deformation of a flattened character image.
class StudyCompanionPainter extends CustomPainter {
  StudyCompanionPainter(
    this.sheet,
    this.seconds, {
    this.resting = false,
    this.reducedMotion = false,
  });
  final ui.Image? sheet;
  final double seconds;
  final bool resting, reducedMotion;

  // Isolated part bounds in the generated 1774×887 atlas, not grid cells.
  static const sources = [
    Rect.fromLTRB(11, 97, 469, 453), // head without eyes
    Rect.fromLTRB(521, 210, 843, 334), // eyes
    Rect.fromLTRB(904, 173, 1304, 433), // torso
    Rect.fromLTRB(1348, 81, 1753, 452), // tail
    Rect.fromLTRB(
      162,
      502,
      365,
      690,
    ), // orange upper arm, joint covered by forearm
    Rect.fromLTRB(581, 506, 758, 827), // gripping forearm/paw
    Rect.fromLTRB(986, 513, 1210, 823), // resting forearm/paw
    Rect.fromLTRB(1287, 595, 1763, 819), // notebook
  ];
  static const bookRect = Rect.fromLTWH(115, 400, 370, 104);

  @override
  void paint(Canvas canvas, Size size) {
    if (sheet == null) return;
    final pose = StudyMotion.sample(
      reducedMotion && seconds >= 0 ? 2 : seconds,
    );
    final paint = Paint()..filterQuality = FilterQuality.medium;
    void part(int index, Rect destination) =>
        canvas.drawImageRect(sheet!, sources[index], destination, paint);
    void bone(int index, Offset start, Offset end, double width, double extra) {
      final delta = end - start;
      canvas.save();
      canvas.translate(start.dx, start.dy);
      canvas.rotate(math.atan2(delta.dy, delta.dx) - math.pi / 2);
      final bounds = Rect.fromLTWH(
        -width / 2,
        index == 4 ? -9 : -20,
        width,
        delta.distance + extra + (index == 4 ? 0 : 11),
      );
      if (index == 4) {
        canvas.clipRRect(
          RRect.fromRectAndRadius(bounds, Radius.circular(width / 2)),
        );
      }
      part(index, bounds);
      canvas.restore();
    }

    canvas.save();
    canvas.scale(size.width / 512, size.height / 512);
    canvas.save();
    canvas.translate(181, 383);
    canvas.rotate(pose.tailAngle);
    part(3, const Rect.fromLTWH(-157, -150, 170, 156));
    canvas.restore();
    part(2, Rect.fromLTWH(184, 302 - pose.breath, 220, 143));
    bone(4, pose.left.shoulder, pose.left.elbow, 43, 19);
    bone(4, pose.right.shoulder, pose.right.elbow, 45, 19);
    // Eyes belong to the head transform; eyelids reveal the underlying face art.
    canvas.save();
    canvas.translate(292, 346 - pose.headLift);
    canvas.rotate(pose.headAngle);
    canvas.translate(-292, -346);
    part(0, const Rect.fromLTWH(141, 109, 307, 239));
    final eyelids = Path();
    final upperLids = Path();
    for (final x in [239.0, 345.0]) {
      final h = 68 * (1 - pose.blink);
      final arc = 5 * pose.blink;
      eyelids.moveTo(x - 36, 282);
      eyelids.cubicTo(
        x - 24,
        282 - h * .67 + arc,
        x + 24,
        282 - h * .67 + arc,
        x + 36,
        282,
      );
      eyelids.cubicTo(
        x + 24,
        282 + h * .67 + arc,
        x - 24,
        282 + h * .67 + arc,
        x - 36,
        282,
      );
      eyelids.close();
      upperLids.moveTo(x - 36, 282);
      upperLids.cubicTo(
        x - 24,
        282 - h * .67 + arc,
        x + 24,
        282 - h * .67 + arc,
        x + 36,
        282,
      );
    }
    canvas.save();
    canvas.clipPath(eyelids);
    final lookingAtPage =
        pose.action == StudyAction.turning ||
        pose.action == StudyAction.reaching;
    final target = lookingAtPage ? pose.right.wrist : pose.penTip;
    final attention = seconds < 0 ? 0.0 : StudyMotion.ease(0, .8, seconds);
    final gaze =
        Offset(((target.dx - 290) / 120).clamp(-1.0, 1.0) * 5, 6) * attention;
    for (final x in [239.0, 345.0]) {
      final eye = Rect.fromCenter(
        center: Offset(x, 282),
        width: 72,
        height: 68,
      );
      canvas.drawOval(eye, Paint()..color = const Color(0xFFFFF9EB));
      canvas.drawOval(
        eye,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 3.1
          ..color = const Color(0xFF291B18),
      );
      final iris = Rect.fromCenter(
        center: eye.center + gaze,
        width: 54,
        height: 54,
      );
      canvas.save();
      canvas.clipPath(Path()..addOval(iris));
      canvas.drawImageRect(
        sheet!,
        const Rect.fromLTRB(559, 232, 656, 329),
        iris,
        paint,
      );
      canvas.restore();
    }
    canvas.restore();
    if (pose.blink > .1) {
      canvas.drawPath(
        upperLids,
        Paint()
          ..color = const Color(0xFF3C211B)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.8
          ..strokeCap = StrokeCap.round,
      );
    }
    canvas.restore();
    part(7, bookRect);
    _paper(canvas, 1);
    _ink(canvas, pose.inkTime);
    if (pose.time >= 18.2 && pose.time < 21.2) _paper(canvas, pose.page);
    // Pencil and paw share the grip; no sliding or opacity changes.
    bone(5, pose.left.elbow, pose.left.wrist, 49, 23);
    _pencil(canvas, pose);
    // A small finger layer covers the shaft at the grip, not the whole pencil.
    canvas.save();
    canvas.clipPath(
      Path()..addOval(
        Rect.fromCenter(center: pose.left.wrist, width: 24, height: 18),
      ),
    );
    bone(5, pose.left.elbow, pose.left.wrist, 49, 23);
    canvas.restore();
    bone(6, pose.right.elbow, pose.right.wrist, 52, 21);
    canvas.restore();
  }

  void _ink(Canvas canvas, double time) {
    final pen = Paint()
      ..color = const Color(0xFF78614A)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.05
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;
    for (final word in StudyMotion.strokes) {
      final p = word.progress(time);
      if (p <= 0) continue;
      final path = Path()..moveTo(word.start.dx, word.start.dy);
      for (var i = 1; i <= 60; i++) {
        final u = math.min(i / 60, p);
        final at = word.point(u);
        path.lineTo(at.dx, at.dy);
        if (u >= p) break;
      }
      canvas.drawPath(path, pen);
    }
  }

  void _paper(Canvas canvas, double progress) {
    final angle = progress * math.pi;
    final corner = StudyMotion.pageCorner(progress);
    final bottom = Offset(
      300 + (180 - progress * 9) * math.cos(angle),
      491 - math.sin(angle) * 22,
    );
    const spine = Offset(300, 408), foot = Offset(300, 491);
    final curl = math.sin(angle) * 13;
    final page = Path()
      ..moveTo(spine.dx, spine.dy)
      ..quadraticBezierTo(
        (spine.dx + corner.dx) / 2,
        corner.dy - curl,
        corner.dx,
        corner.dy,
      )
      ..quadraticBezierTo(
        corner.dx + math.sin(angle) * 6,
        (corner.dy + bottom.dy) / 2,
        bottom.dx,
        bottom.dy,
      )
      ..quadraticBezierTo(
        (bottom.dx + foot.dx) / 2,
        bottom.dy - curl * .3,
        foot.dx,
        foot.dy,
      )
      ..close();
    if (progress > 0 && progress < 1) {
      canvas.drawShadow(
        page,
        const Color(0x884F3521),
        2 + math.sin(angle) * 5,
        false,
      );
    }
    canvas.drawPath(
      page,
      Paint()
        ..shader = ui.Gradient.linear(
          spine,
          corner,
          [
            const Color(0xFFE9D5AC),
            const Color(0xFFFFF5DA),
            const Color(0xFFFFF9E8),
          ],
          const [0, .14, 1],
        ),
    );
    canvas.drawPath(
      page,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.1
        ..color = const Color(0xFFB59772),
    );
  }

  void _pencil(Canvas canvas, StudyPose pose) {
    final tip = pose.penTip;
    final direction = StudyMotion.penVector;
    final top = tip - direction * 58;
    final wood = tip - direction * 8;
    final normal = Offset(-direction.dy, direction.dx);
    final body = Path()
      ..moveTo(top.dx + normal.dx * 3, top.dy + normal.dy * 3)
      ..lineTo(wood.dx + normal.dx * 3, wood.dy + normal.dy * 3)
      ..lineTo(tip.dx, tip.dy)
      ..lineTo(wood.dx - normal.dx * 3, wood.dy - normal.dy * 3)
      ..lineTo(top.dx - normal.dx * 3, top.dy - normal.dy * 3)
      ..close();
    canvas.drawPath(body, Paint()..color = const Color(0xFFF0BD4F));
    canvas.drawPath(
      body,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.4
        ..color = const Color(0xFF62472F),
    );
    canvas.drawLine(
      top,
      wood,
      Paint()
        ..strokeWidth = 1.2
        ..color = const Color(0xFFFFE395),
    );
    canvas.drawLine(
      tip - direction * 3.5,
      tip,
      Paint()
        ..strokeWidth = 1.8
        ..strokeCap = StrokeCap.round
        ..color = const Color(0xFF493B31),
    );
    canvas.drawLine(
      top + direction * 1.5,
      top + direction * 6,
      Paint()
        ..strokeWidth = 5.3
        ..color = const Color(0xFFDA9073),
    );
  }

  @override
  bool shouldRepaint(StudyCompanionPainter oldDelegate) =>
      sheet != oldDelegate.sheet ||
      seconds != oldDelegate.seconds ||
      resting != oldDelegate.resting ||
      reducedMotion != oldDelegate.reducedMotion;
}
