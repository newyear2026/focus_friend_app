import 'dart:math' as math;
import 'dart:ui';

enum StudyAction { writing, reading, reaching, turning, returning }

/// Shared path for visible handwriting and the pencil's contact point.
class InkStroke {
  const InkStroke(this.start, this.width, this.begin);
  final Offset start;
  final double width, begin;
  static const duration = .70;
  Offset point(double progress) {
    final p = progress.clamp(0.0, 1.0);
    return start +
        Offset(
          width * p,
          1.4 * math.sin(p * math.pi * 10) + .65 * math.sin(p * math.pi * 22),
        );
  }

  double progress(double time) {
    final t = ((time - begin) / duration).clamp(0.0, 1.0);
    return t * t * (3 - 2 * t);
  }
}

class ArmPose {
  const ArmPose(this.shoulder, this.elbow, this.wrist);
  final Offset shoulder, elbow, wrist;

  /// Two rigid bones. The elbow bends outward; bone lengths never stretch.
  factory ArmPose.solve(
    Offset shoulder,
    Offset target,
    double upper,
    double lower,
    double bend,
  ) {
    final delta = target - shoulder;
    final distance = delta.distance.clamp(
      (upper - lower).abs() + .01,
      upper + lower - .01,
    );
    final heading = math.atan2(delta.dy, delta.dx);
    final angle = math.acos(
      ((upper * upper + distance * distance - lower * lower) /
              (2 * upper * distance))
          .clamp(-1.0, 1.0),
    );
    final elbow =
        shoulder +
        Offset(
              math.cos(heading + bend * angle),
              math.sin(heading + bend * angle),
            ) *
            upper;
    final wrist =
        shoulder + Offset(math.cos(heading), math.sin(heading)) * distance;
    return ArmPose(shoulder, elbow, wrist);
  }
}

class StudyPose {
  const StudyPose({
    required this.time,
    required this.action,
    required this.penTip,
    required this.penLift,
    required this.left,
    required this.right,
    required this.breath,
    required this.headAngle,
    required this.headLift,
    required this.tailAngle,
    required this.blink,
    required this.page,
    required this.inkTime,
    required this.isWriting,
  });
  final double time,
      penLift,
      breath,
      headAngle,
      headLift,
      tailAngle,
      blink,
      page,
      inkTime;
  final Offset penTip;
  final ArmPose left, right;
  final StudyAction action;
  final bool isWriting;
}

/// Authored 2D action timeline, independent of the durable focus timer.
abstract final class StudyMotion {
  static const cycleSeconds = 24;
  static const penVector = Offset(.342, .940);
  static const readyTip = Offset(153, 418);
  static const restingRight = Offset(372, 401);
  static final strokes = [
    for (var row = 0; row < 4; row++)
      for (var word = 0; word < 3; word++)
        InkStroke(
          Offset(155.0 + word * 37, 426.0 + row * 15),
          [27.0, 30.0, 26.0][word],
          .8 + (row * 3 + word) * .94 + row * .4,
        ),
  ];
  static double ease(double from, double to, double value) {
    final t = ((value - from) / (to - from)).clamp(0.0, 1.0);
    return t * t * (3 - 2 * t);
  }

  static Offset pageCorner(double progress) {
    final angle = progress * math.pi;
    return Offset(
      300 + (169 - progress * 10) * math.cos(angle),
      412 - math.sin(angle) * 55,
    );
  }

  static StudyPose sample(double seconds) {
    final idle = seconds < 0;
    final t = idle ? 0.0 : seconds % cycleSeconds;
    final breath = idle ? 0.0 : 1.5 * math.sin(t * math.pi * 2 / 4.8);
    final writingEnd = strokes.last.begin + InkStroke.duration;
    var tip = readyTip;
    var lift = 8.0;
    var isWriting = false;
    if (!idle && t < .8) {
      tip = Offset.lerp(readyTip, strokes.first.start, ease(0, .8, t))!;
      lift = 8 * (1 - ease(0, .8, t));
    } else if (!idle && t < writingEnd) {
      final index = strokes.lastIndexWhere((stroke) => stroke.begin <= t);
      final stroke = strokes[index];
      if (t <= stroke.begin + InkStroke.duration) {
        tip = stroke.point(stroke.progress(t));
        lift = 0;
        isWriting = true;
      } else {
        final next = strokes[(index + 1).clamp(0, strokes.length - 1)];
        final u = ease(stroke.begin + InkStroke.duration, next.begin, t);
        lift = 8 * math.sin(u * math.pi);
        tip = Offset.lerp(stroke.point(1), next.start, u)! - Offset(0, lift);
      }
    } else if (!idle && t < 15) {
      final u = ease(writingEnd, 15, t);
      tip = Offset.lerp(strokes.last.point(1), const Offset(208, 420), u)!;
      lift = 12 * u;
    } else if (!idle && t < 21.5) {
      tip = const Offset(208, 420);
      lift = 12;
    } else if (!idle) {
      final u = ease(21.5, 23.2, t);
      tip = Offset.lerp(const Offset(208, 420), readyTip, u)!;
      lift = 12 - 4 * u;
    }
    var right = restingRight;
    final page = ease(18.2, 21.2, t);
    if (!idle && t >= 16.4 && t < 18.2) {
      final u = ease(16.4, 18.2, t);
      right =
          Offset.lerp(restingRight, pageCorner(0), u)! -
          Offset(0, 9 * math.sin(u * math.pi));
    } else if (!idle && t >= 18.2 && t < 19.7) {
      right = pageCorner(page);
    } else if (!idle && t >= 19.7 && t < 21.7) {
      right = Offset.lerp(pageCorner(.5), restingRight, ease(19.7, 21.7, t))!;
    }
    var blink = 0.0;
    if (!idle) {
      for (final center in [3.8, 8.9, 15.8, 21.9]) {
        blink = math.max(
          blink,
          ease(center - .10, center, t) *
              (1 - ease(center + .035, center + .18, t)),
        );
      }
    }
    final down = ease(0, 1, t) * (1 - ease(14, 16, t));
    final review = ease(14, 15.5, t) * (1 - ease(16.4, 18, t));
    final grip = tip - penVector * 29;
    return StudyPose(
      time: t,
      action: t < 14
          ? StudyAction.writing
          : t < 16.4
          ? StudyAction.reading
          : t < 18.2
          ? StudyAction.reaching
          : t < 21.2
          ? StudyAction.turning
          : StudyAction.returning,
      penTip: tip,
      penLift: lift,
      left: ArmPose.solve(Offset(201, 357 - breath), grip, 44, 70, 1),
      right: ArmPose.solve(Offset(385, 346 - breath), right, 51, 69, -1),
      breath: breath,
      headAngle: idle ? 0 : .05 * down + .025 * math.sin(t * math.pi * 2 / 12),
      headLift: breath - review * 4,
      tailAngle: idle ? 0 : .06 * math.sin(t * math.pi * 2 / 8),
      blink: blink,
      page: page,
      inkTime: idle || t >= 21.2 ? 0 : t,
      isWriting: isWriting,
    );
  }
}
