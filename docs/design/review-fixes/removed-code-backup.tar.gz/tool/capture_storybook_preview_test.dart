// Renders production scene widgets with every reward; no device data access.
import 'dart:io';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:focus_friend_app/room_ambience.dart';
import 'package:focus_friend_app/study_scene.dart';

void main() {
  testWidgets('capture the storybook room in all four periods', (tester) async {
    tester.view.physicalSize = const Size(1182, 1330);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    final output = Directory('docs/design/unified-room-style');
    output.createSync(recursive: true);
    for (final ambience in RoomAmbience.values) {
      final boundaryKey = GlobalKey();
      await tester.pumpWidget(
        MaterialApp(
          home: RepaintBoundary(
            key: boundaryKey,
            child: ColoredBox(
              color: const Color(0xFFFFFEFA),
              child: DeskIllustration(
                unlocked: const {'plant', 'mug', 'lamp'},
                ambience: ambience,
              ),
            ),
          ),
        ),
      );
      final context = tester.element(find.byType(DeskIllustration));
      await tester.runAsync(() async {
        for (final asset in [
          ambience.asset,
          StudyAnimation.asset,
          for (final reward in ['plant', 'mug', 'lamp'])
            'assets/images/storybook/reward-$reward.png',
        ]) {
          await precacheImage(AssetImage(asset), context);
        }
      });
      await tester.pumpAndSettle();
      expect(tester.takeException(), isNull);
      final boundary =
          boundaryKey.currentContext!.findRenderObject()!
              as RenderRepaintBoundary;
      await tester.runAsync(() async {
        final image = await boundary.toImage();
        final png = await image.toByteData(format: ui.ImageByteFormat.png);
        await File(
          '${output.path}/scene-${ambience.assetName}.png',
        ).writeAsBytes(png!.buffer.asUint8List());
        image.dispose();
      });
    }
    await tester.pumpWidget(const SizedBox.shrink());
  });
}
