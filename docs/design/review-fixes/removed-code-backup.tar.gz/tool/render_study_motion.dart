// flutter test tool/render_study_motion.dart
// Production 12fps sprite preview; no app data access.
import 'dart:io';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:focus_friend_app/study_scene.dart';

void main() {
  testWidgets('export production study motion', (tester) async {
    await tester.runAsync(() async {
      Future<ui.Image> load(String path) async {
        final codec = await ui.instantiateImageCodec(
          await File(path).readAsBytes(),
        );
        final image = (await codec.getNextFrame()).image;
        codec.dispose();
        return image;
      }

      final sheet = await load(StudyAnimation.asset);
      final room = await load('assets/images/storybook/room-day.png');
      const isolated = bool.fromEnvironment('CHARACTER_ONLY');
      final output = Directory(
        const String.fromEnvironment(
          'MOTION_PREVIEW_DIR',
          defaultValue: isolated
              ? '/tmp/focus-cel-character-frames'
              : '/tmp/focus-cel-room-frames',
        ),
      );
      await output.create(recursive: true);
      for (
        var frame = 0;
        frame < StudyAnimation.cycleTicks;
        frame += const int.fromEnvironment('FRAME_STEP', defaultValue: 1)
      ) {
        final recorder = ui.PictureRecorder();
        final canvas = Canvas(recorder);
        canvas.drawColor(const Color(0xFFFFFEFA), BlendMode.src);
        if (isolated) {
          canvas.translate(0, 0);
        } else {
          canvas.scale(480 / 1182, 540 / 1330);
          canvas.drawImageRect(
            room,
            Rect.fromLTWH(0, 0, room.width.toDouble(), room.height.toDouble()),
            const Rect.fromLTWH(0, 0, 1182, 1330),
            Paint()..filterQuality = FilterQuality.medium,
          );
          canvas.translate(
            DeskIllustration.companionBounds.left,
            DeskIllustration.companionBounds.top,
          );
        }
        StudyCompanionPainter(
          sheet,
          (frame * 1000000 / StudyAnimation.framesPerSecond).ceil() / 1000000,
        ).paint(
          canvas,
          isolated
              ? const Size(512, 512)
              : DeskIllustration.companionBounds.size,
        );
        final picture = recorder.endRecording();
        final image = await picture.toImage(
          isolated ? 512 : 480,
          isolated ? 512 : 540,
        );
        picture.dispose();
        final png = await image.toByteData(format: ui.ImageByteFormat.png);
        await File(
          '${output.path}/${frame.toString().padLeft(4, '0')}.png',
        ).writeAsBytes(png!.buffer.asUint8List());
        image.dispose();
      }
      sheet.dispose();
      room.dispose();
    });
  });
}
